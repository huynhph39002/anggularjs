console.log('Log de kiem tra: Da nhumg file page/product/list.js thanh cong')
// khai bao controller listProductCtrl
app.controller('listProductCtrl', function($scope,$http){
    console.log('Log de kiem tra : khai bao listProductCtrl thanh cong');
})
