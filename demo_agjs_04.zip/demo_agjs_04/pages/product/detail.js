console.log('Log de kiem tra: Da nhumg file page/product/detail.js thanh cong')
// khai bao controller detailProductCtrl
//luu y: khai bao "$routeParam"de co the lay gia tri truyen vao url
app.controller('detalProductCtrl',function($scope,$http,$routeParams){
    console.log('log de kiem tra : khai bao detailProductCtrl thanh cong');
     console.log('log de in thu gia tri param tu url', $routeParams);
})