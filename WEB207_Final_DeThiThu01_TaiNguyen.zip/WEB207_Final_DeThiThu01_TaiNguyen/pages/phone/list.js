console.log('Log để kiểm tra: Đã nhúng file pages/product/list.js thành công');

// 5.1. Khai báo controller listPhoneCtrl
app.controller('listPhoneCtrl', function ($scope, $http) {
    console.log('Log để kiểm tra: Khai báo listPhoneCtrl thành công');



})
