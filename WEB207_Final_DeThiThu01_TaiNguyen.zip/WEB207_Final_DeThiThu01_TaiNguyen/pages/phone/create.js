console.log('Log để kiểm tra: Đã nhúng file pages/product/create.js thành công');

// Khai báo controller creatPhoneCtrl
app.controller('creatPhoneCtrl', function ($scope, $http) {
    console.log('Log để kiểm tra: Khai báo creatPhoneCtrl thành công');




})
