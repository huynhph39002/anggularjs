console.log('Log để kiểm tra: Đã nhúng file pages/product/edit.js thành công');

// Khai báo controller editPhoneCtrl
app.controller('editPhoneCtrl', function ($scope, $http, $routeParams) {
    console.log('Log để kiểm tra: Khai báo editPhoneCtrl thành công');
    console.log('Log để in thử giá trị params từ url', $routeParams);



})
